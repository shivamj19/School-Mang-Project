# School-Mang-System
basic school management system core java app 
